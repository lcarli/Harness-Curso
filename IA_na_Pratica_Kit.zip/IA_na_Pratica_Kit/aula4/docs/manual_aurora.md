# Manual de Atendimento do Café Aurora

Documento interno (fictício) usado pela equipe e pela assistente virtual Aurora.
Versão 1.3 — atualizado em outubro de 2026.

## Horários

O Café Aurora funciona de segunda a sábado, das 7h às 19h, e aos domingos, das 8h às 13h.
Em feriados nacionais abrimos no horário de domingo (8h às 13h). Nos dias 25 de dezembro e 1º de janeiro o café fica fechado.

A cozinha para de aceitar pedidos de itens quentes 15 minutos antes do fechamento.
O pão de queijo sai quentinho do forno duas vezes por dia: às 7h e às 16h. Aos domingos, sai apenas às 8h.

## Cardápio e preços

Bebidas:
- Café espresso: R$ 6,00
- Cappuccino: R$ 11,00

Comidas:
- Pão de queijo (unidade): R$ 4,50
- Croissant: R$ 9,00
- Bolo de cenoura (fatia): R$ 8,00

Os preços valem para consumo no local e para viagem. Não cobramos taxa de serviço.
Aceitamos Pix, cartão de débito e cartão de crédito. Não aceitamos cheque nem vale-refeição.
A equipe não está autorizada a conceder descontos fora do programa de fidelidade.

## Alergênicos

Informe sempre os alergênicos quando o cliente perguntar. Em caso de dúvida, não arrisque: diga que vai verificar com a cozinha.

- Croissant: contém amêndoas e glúten (feito com farinha de trigo e recheio de creme de amêndoas).
- Pão de queijo: contém leite e ovos. Não contém glúten (feito com polvilho).
- Bolo de cenoura: contém ovos, trigo e leite.
- Café espresso: não contém alergênicos. O cappuccino contém leite.

Atenção: todos os itens são preparados na mesma cozinha, portanto pode haver traços de glúten, leite, ovos e amêndoas em qualquer produto. Clientes com alergia grave devem ser avisados disso.
Não oferecemos, no momento, leite vegetal.

## Política de trocas e reclamações

Se o cliente não ficar satisfeito com um produto, ele pode pedir a troca no balcão em até 30 minutos após a compra, apresentando o comprovante.
Não fazemos devolução em dinheiro; oferecemos a troca por outro item de mesmo valor.

Reclamações devem ser registradas com nome e horário da compra no caderno de ocorrências do balcão ou pelo e-mail de atendimento divulgado no cardápio impresso.
A gerência responde em até 2 dias úteis. A assistente virtual nunca deve prometer reembolso, brinde ou desconto como compensação: ela deve acolher a reclamação e encaminhá-la à gerência.

## Encomendas

Aceitamos encomendas de pão de queijo, croissant e bolo de cenoura para festas e eventos.
Toda encomenda precisa ser feita com no mínimo 24 horas de antecedência.
Pedidos acima de 50 unidades exigem um sinal de 30% do valor total, pago via Pix no momento da encomenda.
A retirada é feita no balcão, no horário combinado. No momento, não fazemos entregas.
Cancelamentos com menos de 12 horas de antecedência não têm o sinal devolvido.

## Wi-Fi e ambiente

O Wi-Fi é gratuito para clientes. A senha está impressa no comprovante de compra e muda toda segunda-feira.
O café tem 12 mesas internas e 4 mesas na calçada. Animais de estimação são bem-vindos nas mesas da calçada.
Há tomadas nas mesas encostadas na parede. Pedimos que o uso de notebooks seja limitado a 2 horas nos horários de pico (7h às 9h e 12h às 14h).
O ambiente é climatizado e possui acesso para cadeira de rodas e banheiro adaptado.

## Fidelidade

O programa de fidelidade Amigo da Aurora é gratuito: basta informar o nome no caixa.
A cada 10 cafés comprados, o cliente ganha 1 café grátis. Vale para espresso e cappuccino.
Os pontos não expiram, mas são pessoais e não podem ser transferidos.
O café grátis não pode ser trocado por dinheiro nem por outro produto.
