---
description: Monta o cardápio do dia do Café Aurora
---
Monte o cardápio do dia do Café Aurora usando SOMENTE estes itens:

| Item | Preço |
|---|---|
| Café espresso | R$ 6,00 |
| Cappuccino | R$ 11,00 |
| Pão de queijo (unidade) | R$ 4,50 |
| Croissant | R$ 9,00 |
| Bolo de cenoura (fatia) | R$ 8,00 |

Formato da resposta:
1. Um título criativo para o dia.
2. Uma tabela com item, preço e uma frase curta e apetitosa.
3. Uma sugestão de combo (sem desconto).
